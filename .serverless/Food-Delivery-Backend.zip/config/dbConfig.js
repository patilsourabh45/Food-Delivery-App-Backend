const DbConfig = {
  USERNAME: 'patilsourabh46',
  PASSWORD: 'PATILSJP',
  // PASSWORD: 'fsdffdf',
  CLUSTER_ADDRESS: 'cluster0.jkqng.mongodb.net',
  DATABASE_NAME:'NodewithDB',
};

module.exports = DbConfig;